<?php 
/**
  * Script to send firebase notification to the user device
  *
  * It accepts the parameter user_firebase_id,notification_message,notification_title using GET
  * 
  * @return JSON
  * @author Pelumi Oyefeso, Precious Omonzejele
  */
  require "../inc/_config.php"; 
$firebase_id = isset($_GET['user_firebase_id']) ? strip_tags(trim($_GET['user_firebase_id'])) : false;	
$notification_message = isset($_GET['notification_message']) ? strip_tags(trim($_GET['notification_message'])) : false;	
$notification_title = isset($_GET['notification_title']) ? strip_tags(trim($_GET['notification_title'])) : false;
if(!($firebase_id && $notification_message && $notification_title)){
	pekky_set_failure_state(0,"empty field(s)"); 
    exit(pekky_print_json_state());//end the program 
}
$curl = curl_init();	
$authToken = "AAAAifjJuok:APA91bFwkK_H3dKVajfUcNpKop8eoEN1qgxjKuPFKprNdOsiHDFxRn7c6zQC3eD16YincY8zF648dNwCNrPIpAKqQKOYt-3Bqb3zNz2GURMB8F7vUrpotwQwAE-5AHP0v2mpjwYhn6Ie";
$postData = array(
				'to' => $firebase_id,
				'priority' => 'high',
				'notification' => array('sound' => 'enabled', 'title' => $notification_title, 'body' => $notification_message, 
					'tag' => '1')
			);

	// Set some options - we are passing in a useragent too here
	curl_setopt_array($curl, array(
		CURLOPT_HTTPHEADER => array(
			'Authorization:key='. $authToken,
			'Content-Type: application/json'
		),
		CURLOPT_RETURNTRANSFER => TRUE,
		CURLOPT_URL => 'http://fcm.googleapis.com/fcm/send',
		CURLOPT_POST => TRUE,
		CURLOPT_POSTFIELDS => json_encode($postData)
));
// Send the request & save response to $resp
$response = curl_exec($curl);
if($response === FALSE){
    die(curl_error($curl));
}
$responseData = json_decode($response, TRUE);
echo $response . "<br>";
//echo $responseData;
// Close request to clear up some resources
curl_close($curl);


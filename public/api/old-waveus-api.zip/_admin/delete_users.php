<?php
 /**
  * Script to delete user(s)
  *
  * It accepts the parameter user_id,ids(this should be in csv),user_type using GET
  * Please note that this file only helps handle, determine and prevent any empty parameter
  * If a required parameter is empty, it'll return false
  * You should make sure all those are handled on your end
  * 
  * @return JSON success,total,deleted on success or Error status on failure.
  * @author Precious Omonzejele <omonze@peepsipi.com>
  */
 // header("Content-Type: application/json");
  require "../inc/_config.php";
  require "../vendor/autoload.php";
 
  $user_id = isset($_GET["user_id"]) ? $_GET["user_id"] : false;
  $ids = isset($_GET["ids"]) ? trim($_GET["ids"]) : false;
  $user_type = isset($_GET["user_type"]) ? $_GET["user_type"] : 1;
  if(!($user_id && $ids)){
    pekky_set_failure_state(0,"empty field(s)");
    exit(pekky_print_json_state());//end the program
  }
  $db = new DBCon(CON_TYPE);
  $con = $db->connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
 $dbq = new Query($con);
 //check if user exists, to preceed with the action
 if(!user_exists($dbq,$user_id,3)){
    pekky_set_failure_state(0,'User doesn\'t exist');
    exit(pekky_print_json_state());
 }

 $user_db = user_type($user_type);
 //now start deleting
//get the value through csv
$delete_records = explode(',',$ids);
//$dbq->prepare("UPDATE ".$user_db." SET deleted = '1' WHERE id = ?");
$total = count($delete_records);
$s = 0;//for counting success
for($i = 0; $i < $total; $i++){
  if(!empty(trim($delete_records[$i]))){
  $dbq->change($user_db,['deleted'=>'1'],"WHERE id = ?",[$delete_records[$i]]);
  var_dump($dbq);
    if($dbq->rows_affected == 1){
        $s++;
    }
  }
}
pekky_set_success_state();
pekky_print_json_state(['total'=>$total,'deleted'=>$s]);

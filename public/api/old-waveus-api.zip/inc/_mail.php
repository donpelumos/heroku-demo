<?php 
/**
 * For mail stuff
 * @author Precious Omonzejele <omonze@peepsipi.com>
 */

/**
 * Mail method to send
 * 
 * @param string $from sets who the mail is from
 * @param string $to a valid email to send to
 * @param string $subject subject of the mail
 * @param string $msg message of the mail
 * @return bool true if sent, false otherwise
 */
 function email_send($from,$to,$subject,$msg){
	$headers = "From: ".$from." \r\n";
	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
	$send = mail($to, $subject, "<p style=\"line-height:32px;\">".$msg."</p>",$headers);
	return $send;
 }
/**
 * Order mail template
 * 
 * Helps construct a default email for the order
 * 
 * @param object $query the query object
 * @param int $order_id the order id
 * @param string $order_type the type of order
 * @param mixed $user_id the user id, to get the details
 * @param int $user_type (optional) the type of user, default is 1
 * @param bool $for_admin (optional) if it's for admin, default is false
 * @param string $msg (optional) in case you want to change the default message
 * @return bool, true if message sent, false otherwise
 */
 function order_mail_template($query,$order_id,$order_type,$user_id,$user_type = 1,$for_admin = false,$msg = ''){
	$msg = (isset($msg) ? trim($msg) : '');
	$order_type = (isset($order_type) ? $order_type : 1);
	$user_type = (isset($user_type) ? $user_type : 1);
	$subject = '';
	$message = '';
	//get user info
	$user_db = 	user_type($user_type);
	$query->set_fetch_mode("assoc");
	$query->get(query_live("select fullname,email FROM ".$user_db." WHERE id = ?"),[$user_id]);
	$user_record = for_single_array($query->record);
	$name = $user_record['fullname'];
	if($for_admin == true)
		$user_type = 3;
	$ini_msg = order_msg_template($query,$order_id,$order_type,$user_type,$name);
	//get order_time
	$query->get(query_live("select date_time FROM orders WHERE id = ?"),[$order_id]);
	$order_record = for_single_array($query->record);
	
	$order_stuff = array(
        3 => array('user'=> array(),'dispatcher'=> array(),'admin'=> array()),//completed
        2 => array('user'=> array(),'dispatcher'=> array(),'admin'=> array()),//processing
        1 => array('user'=> array(),'dispatcher'=> array(),'admin'=> array()),//on hold
        0 => array('user'=> array(),'dispatcher'=> array(),'admin'=> array())//cancelled
	);
	//completed
	$order_stuff[3]['user'] = ['sub'=> '','msg'=>$ini_msg];
	$order_stuff[3]['dispatcher'] = ['sub'=> '', 'msg'=>$ini_msg];
	$order_stuff[3]['admin'] = ['sub'=> '', 'msg'=>$ini_msg];
	//processing
	$order_stuff[2]['user'] = ['sub'=> '', 'msg'=>$ini_msg];
	$order_stuff[2]['dispatcher'] = ['sub'=> '', 'msg'=>$ini_msg];
	$order_stuff[2]['admin'] = ['sub'=> '', 'msg'=>$ini_msg];
	//on hold
	$order_stuff[1]['user'] = ['sub'=> '', 'msg'=>$ini_msg];
	$order_stuff[1]['dispatcher'] = ['sub'=> '', 'msg'=>$ini_msg];
	$order_stuff[1]['admin'] = ['sub'=> '', 'msg'=>$ini_msg];
	//cancelled
	$order_stuff[0]['user'] = ['sub'=> '', 'msg'=>$ini_msg];
	$order_stuff[0]['dispatcher'] = ['sub'=> '', 'msg'=>$ini_msg];
	$order_stuff[0]['admin'] = ['sub'=> '', 'msg'=>$ini_msg];
  
	$user_stuff = '';
	switch($user_type){
		 case 2://dispatcher 
			$user_stuff = 'dispatcher'; 
			$subject = SITE_TITLE.' order receipt from '.date('M, d Y',strtotime($order_record['date_time']));
		break;
		case 3: //admin
			$user_stuff = 'admin'; 
			$subject = ''.SITE_TITLE.' order(#'.$order_id.') receipt from '.date('M, d Y',strtotime($order_record['date_time']));
		break;
		default://user	
			$user_stuff = 'user';
			$subject = 'Your '.SITE_TITLE.' order(#'.$order_id.') on '.date('M, d Y',strtotime($order_record['date_time']));
	}
	//$subject = $order_stuff[$order_type][$user_stuff]['sub'];
	$message = (!empty($msg) ? $msg : $order_stuff[$order_type][$user_stuff]['msg']);
	//send
	$f_email = get_site_option($query,'order_email');
	$from = SITE_TITLE.' order emails <'.$f_email.'>';
	$to = $user_record['email'];
	if($for_admin){
		$to = $f_email;
	}
	//echo '<br><br>'.$to.'<br>'.$from.'<br>'.$subject.'<br/>'.$message;
	if(email_send($from,$to,$subject,$message)){return true;}
	else{return false;}
	
 }

/** 
 * Helps construct a message based on order type
 * 
 * @param object $query the query object
 * @param int $order_id the order id
 * @param string $order_type the type of order
 * @param int $user_type the type of user
 * @return string the msg
 */ 
function order_msg_template($query,$order_id,$order_type,$user_type,$user_name){
	global $meta_backend;
	$user_name = isset($user_name) ? trim($user_name) : '';
	$msg = '';
	$msg_1 = '';
	$msg_state = '';
	$msg_2 = '';
	$msg_footer = '';
	switch($user_type){
		case 3:
		$msg_1 .='<h3>Order <strong>#'.$order_id.'</strong> by <strong>'.$user_name.'</strong> ';
		$msg_2 .= '</h3><h4>Order details are shown below for your reference</h4>';
		$msg_footer .='<p style="border:1px solid rgba(0,0,0,0.1);">Please keep this email for reference
		purpose.<br/> <i>Delivery could take 24 to 72 hours.</i>
		</p><p style="text-align:center;">'.SITE_TITLE.' team.</p>';
		break;
		default://user
		$msg_1 .='<h3>Your order <strong>#'.$order_id.'</strong> ';
		$msg_2 .= '</h3><h4>Your order details are shown below for your reference</h4>';
		$msg_footer .='<p style="border:1px solid rgba(0,0,0,0.1);">Please keep this email for invoice/reference
		purpose.<br/>Thank you for your order. <i>Delivery could take 24 to 72 hours.</i>
		</p><p style="text-align:center;">'.SITE_TITLE.' team.</p>';
	}
	switch($order_type){
		case 3:
		$msg_state .= 'has been completed';//completed
		break;
		case 2:
		$msg_state .= 'is now being processed';//processing
		break;
		case 1:
		$msg_state .= 'is on-hold until a dispatcher picks up '.(($user_type == 1)?'your':'the').' order';//on hold
		break;
		default:
		$msg_state .= 'has been cancelled';//cancelled
	}
	$msg .= $msg_1.' '.$msg_state.' '.$msg_2;
	$table_ish = '<table><thead><tr><td>Head</td><td>Tail</td></tr></thead><tbody>';
	//get the price 
	$query->set_fetch_mode("assoc");
	$query->get("SELECT price from orders WHERE id = ?",[$order_id]);
	$price = trim($query->record[0]['price']);
	if(!empty($price))
		$table_ish .= '<tr><td>price</td><td>'.$price.'</td></tr>';
	//get the order meta.
	$order_meta = get_order_meta($query,$order_id,'','shown');
	foreach($order_meta as $key => $value){
		if(!in_array($key,$meta_backend))
	    	$table_ish .= '<tr><td>'.str_replace('_',' ',$key).'</td><td>'.$value.'</td></tr>';
	}
	$table_ish .='</tbody></table>';
	$msg .= $table_ish.$msg_footer;
	return $msg;
}

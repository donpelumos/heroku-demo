<?php
 /**
  * Script to get site option details,all
  *
  * It accepts the parameter user_id using GET
  * Please note that this file only helps handle, determine and prevent any empty parameter
  * If a required parameter is empty, it'll return false
  * You should make sure all those are handled on your end
  * 
  * @return JSON success on success or Error status on failure.
  * @author Precious Omonzejele <omonze@peepsipi.com>
  */
  header("Content-Type: application/json");
  require "../inc/_config.php";
  require "../vendor/autoload.php";
 
  $user_id = isset($_GET["user_id"]) ? $_GET["user_id"] : false;
  if(!($user_id)){
    pekky_set_failure_state(0,"empty field(s)");
    exit(pekky_print_json_state());//end the program
  }
  $db = new DBCon(CON_TYPE);
  $con = $db->connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
 $dbq = new Query($con);
 $dbq->set_fetch_mode("assoc");
 //check if user exists
 if(!user_exists($dbq,$user_id,3) ){
    pekky_set_failure_state(0,'User doesn\'t exist');
    exit(pekky_print_json_state());
 }
//carry on, just call my function, no stress :) life's good like LG
if(!$dbq->get("SELECT id,option_name,option_value FROM site_options")){
  pekky_set_failure_state(-1,$dbq->err_msg);
  exit(pekky_print_json_state());//end the program
}
//we hope it all went well, can't really determine, return true
pekky_set_success_state();
pekky_print_json_state($dbq->record,'data',false);

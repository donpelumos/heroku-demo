<?php
// Silence is all about being the snake in the monkey shadow :)
